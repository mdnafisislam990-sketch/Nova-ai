package com.novaai.assistant.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.novaai.assistant.data.Store

@Composable
fun PromptDialog(title: String, hint: String, initial: String = "", onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var t by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = NovaColors.Navy2,
        title = { Text(title) },
        text = { OutlinedTextField(t, { t = it }, placeholder = { Text(hint) }, modifier = Modifier.fillMaxWidth()) },
        confirmButton = { TextButton(onClick = { if (t.isNotBlank()) onOk(t.trim()) }) { Text("OK") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun KeysDialog(onDismiss: () -> Unit) {
    var gem by remember { mutableStateOf(Store.str("k_gemini")) }
    var groq by remember { mutableStateOf(Store.str("k_groq")) }
    var oai by remember { mutableStateOf(Store.str("k_openai")) }
    var mg by remember { mutableStateOf(Store.str("m_gemini")) }
    var mq by remember { mutableStateOf(Store.str("m_groq")) }
    var mo by remember { mutableStateOf(Store.str("m_openai")) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = NovaColors.Navy2,
        title = { Text("AI connections") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("Fill at least one key. Nova uses Gemini first, then Groq, then OpenAI. Keys stay on this phone.",
                    fontSize = 12.sp, color = NovaColors.TextDim)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(gem, { gem = it }, label = { Text("Gemini API key") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(groq, { groq = it }, label = { Text("Groq API key") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(oai, { oai = it }, label = { Text("OpenAI API key") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Text("Optional model names (only change if a model stops working)", fontSize = 11.sp, color = NovaColors.TextDim)
                OutlinedTextField(mg, { mg = it }, label = { Text("Gemini model") }, placeholder = { Text("gemini-flash-latest") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(mq, { mq = it }, label = { Text("Groq model") }, placeholder = { Text("llama-3.3-70b-versatile") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(mo, { mo = it }, label = { Text("OpenAI model") }, placeholder = { Text("gpt-4o-mini") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton(onClick = {
                Store.put("k_gemini", gem.trim()); Store.put("k_groq", groq.trim()); Store.put("k_openai", oai.trim())
                Store.put("m_gemini", mg.trim()); Store.put("m_groq", mq.trim()); Store.put("m_openai", mo.trim())
                onDismiss()
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
