package com.novaai.assistant

import android.Manifest
import android.graphics.Color as AColor
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.novaai.assistant.ai.ChatEngine
import com.novaai.assistant.assist.WakeWordService
import com.novaai.assistant.data.Store
import com.novaai.assistant.ui.*
import com.novaai.assistant.utils.Perms
import com.novaai.assistant.utils.toast
import com.novaai.assistant.voice.Stt
import com.novaai.assistant.widget.NovaNotification
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT)
        )
        setContent { NovaTheme { NovaRoot() } }
    }
}

private class Tab(val route: String, val label: String, val icon: String)

@Composable
fun NovaRoot() {
    val ctx = LocalContext.current
    val nav = rememberNavController()
    val scope = rememberCoroutineScope()
    val stt = remember { Stt(ctx) }
    var listening by remember { mutableStateOf(false) }
    var showKeys by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<(() -> Unit)?>(null) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        val p = pending; pending = null; p?.invoke()
    }
    DisposableEffect(Unit) { onDispose { stt.stop() } }

    fun withPerms(perms: List<String>, block: () -> Unit) {
        val need = perms.filter { !Perms.has(ctx, it) }
        if (need.isEmpty()) block() else { pending = block; permLauncher.launch(need.toTypedArray()) }
    }
    val notifPerm: List<String> = if (Build.VERSION.SDK_INT >= 33) listOf(Manifest.permission.POST_NOTIFICATIONS) else emptyList()

    fun goChat() { nav.navigate("chat") { launchSingleTop = true } }

    fun talk() {
        withPerms(listOf(Manifest.permission.RECORD_AUDIO)) {
            if (!Perms.has(ctx, Manifest.permission.RECORD_AUDIO)) { ctx.toast("Allow the microphone to talk to Nova"); return@withPerms }
            if (listening) { stt.stop(); listening = false; return@withPerms }
            listening = true
            stt.start(
                onText = { t -> listening = false; goChat(); scope.launch { ChatEngine.send(ctx, t, speak = true) } },
                onFail = { m -> listening = false; ctx.toast(m) }
            )
        }
    }

    fun onHey(on: Boolean) {
        if (!on) { WakeWordService.stop(ctx); Store.setHey(false); return }
        withPerms(listOf(Manifest.permission.RECORD_AUDIO) + notifPerm) {
            when {
                !Perms.has(ctx, Manifest.permission.RECORD_AUDIO) -> ctx.toast("Microphone permission is needed")
                !Perms.overlay(ctx) -> { ctx.toast("Allow 'Display over other apps', then switch Hey Nova on again"); Perms.openOverlaySettings(ctx) }
                else -> { Store.setHey(true); WakeWordService.start(ctx) }
            }
        }
    }

    fun onNotif(on: Boolean) {
        if (!on) { NovaNotification.cancel(ctx); Store.setNotif(false); return }
        withPerms(notifPerm) {
            if (!Perms.overlay(ctx)) {
                ctx.toast("Allow 'Display over other apps', then switch it on again"); Perms.openOverlaySettings(ctx)
            } else { Store.setNotif(true); NovaNotification.post(ctx) }
        }
    }

    val tabs = listOf(Tab("home", "Home", "🏠"), Tab("chat", "Chat", "💬"), Tab("history", "History", "🕘"), Tab("settings", "Settings", "⚙️"))
    val route = nav.currentBackStackEntryAsState().value?.destination?.route

    Box(Modifier.fillMaxSize().background(NovaBg)) {
        Scaffold(
            containerColor = Color.Transparent,
            modifier = Modifier.imePadding(),
            bottomBar = { if (route in tabs.map { it.route }) NovaBottomBar(tabs, route, nav, listening) { talk() } }
        ) { pad ->
            NavHost(nav, startDestination = "home", modifier = Modifier.padding(pad)) {
                composable("home") {
                    HomeScreen(
                        onNav = { r -> nav.navigate(r) { launchSingleTop = true } },
                        onTalk = { talk() }, listening = listening,
                        onAsk = { q -> goChat(); scope.launch { ChatEngine.send(ctx, q, speak = false) } }
                    )
                }
                composable("chat") { ChatScreen(onKeys = { showKeys = true }) }
                composable("history") { HistoryScreen() }
                composable("settings") {
                    SettingsScreen(onNav = { r -> nav.navigate(r) }, onKeys = { showKeys = true }, onHey = { onHey(it) }, onNotif = { onNotif(it) })
                }
                composable("help") { HelpFeedbackScreen(onBack = { nav.popBackStack() }) }
                composable("follow") { FollowScreen(onBack = { nav.popBackStack() }) }
                composable("memory") { MemoryScreen() }
            }
        }
    }
    if (showKeys) KeysDialog(onDismiss = { showKeys = false })
}

@Composable
private fun NovaBottomBar(tabs: List<Tab>, route: String?, nav: NavController, listening: Boolean, onMic: () -> Unit) {
    NavigationBar(containerColor = NovaColors.Navy2) {
        tabs.take(2).forEach { NavItem(it, route, nav) }
        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
            Box(
                Modifier.size(54.dp)
                    .shadow(if (listening) 24.dp else 14.dp, CircleShape, ambientColor = NovaColors.Purple, spotColor = NovaColors.Cyan)
                    .clip(CircleShape).background(NovaGrad).clickable(onClick = onMic),
                contentAlignment = Alignment.Center
            ) { Text(if (listening) "⏹" else "🎙️", fontSize = 22.sp) }
        }
        tabs.drop(2).forEach { NavItem(it, route, nav) }
    }
}

@Composable
private fun RowScope.NavItem(t: Tab, route: String?, nav: NavController) {
    NavigationBarItem(
        selected = route == t.route,
        onClick = { nav.navigate(t.route) { launchSingleTop = true; popUpTo("home") } },
        icon = { Text(t.icon, fontSize = 20.sp) },
        label = { Text(t.label, fontSize = 10.sp) },
        colors = NavigationBarItemDefaults.colors(
            selectedTextColor = NovaColors.Cyan, unselectedTextColor = NovaColors.TextDim, indicatorColor = NovaColors.Navy
        )
    )
}
