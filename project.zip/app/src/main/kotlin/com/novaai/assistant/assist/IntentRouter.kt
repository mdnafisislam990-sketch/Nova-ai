package com.novaai.assistant.assist

import android.content.Context
import com.novaai.assistant.control.DeviceActions
import com.novaai.assistant.data.Repo

data class Routed(
    val handled: Boolean,
    val reply: String = "",
    val close: Boolean = false,
    val searchQuery: String? = null
)

object IntentRouter {
    private fun has(t: String, vararg k: String) = k.any { t.contains(it) }

    private fun bnDigits(s: String): String {
        val sb = StringBuilder()
        for (c in s) sb.append(if (c in '\u09E6'..'\u09EF') ('0' + (c - '\u09E6')) else c)
        return sb.toString()
    }

    private val stop = setOf("open", "launch", "ওপেন", "খোলো", "খোল", "করো", "কর", "চালু", "চালাও", "দাও", "the", "app", "অ্যাপ", "টা")

    suspend fun route(ctx: Context, raw: String): Routed {
        val t = bnDigits(raw).lowercase().trim()

        if (has(t, "goodbye", "good bye", "bye nova", "bye bye", "বিদায়", "টা টা"))
            return Routed(true, "Goodbye! Call me anytime.", close = true)

        val mem = has(t, "memory", "ram", "মেমরি", "মেমোরি", "র‍্যাম", "ব্যাকগ্রাউন্ড", "background")
        val clr = has(t, "clear", "clean", "free", "পরিষ্কার", "ক্লিয়ার", "খালি", "মুছ")
        if (mem && clr) return Routed(true, DeviceActions.clearBackground(ctx))

        if (has(t, "alarm", "অ্যালার্ম", "এলার্ম", "অ্যালারাম"))
            return Routed(true, DeviceActions.setAlarmFromText(ctx, t))

        Regex("^(?:remind me to|remind me|reminder|add task)\\s+(.+)$").find(t)?.let {
            Repo.addTask(it.groupValues[1]); return Routed(true, "Reminder added: ${it.groupValues[1]}")
        }
        Regex("^(.+?)\\s*(?:মনে করিয়ে দাও|মনে করাও)$").find(t)?.let {
            Repo.addTask(it.groupValues[1]); return Routed(true, "Reminder added: ${it.groupValues[1]}")
        }

        val sq = Regex("^(?:google search|search for|search|google|সার্চ)\\s+(.+)$").find(t)?.groupValues?.get(1)
            ?: Regex("^(.+?)\\s*(?:সার্চ করো|সার্চ কর|গুগলে খোঁজো|গুগলে সার্চ করো)$").find(t)?.groupValues?.get(1)
        if (sq != null) return Routed(true, "Searching Google for $sq", searchQuery = sq)

        val words = t.split(" ").filter { it.isNotBlank() }
        val openWord = has(t, "open", "launch", "ওপেন", "খোল", "চালু", "চালাও")
        if (openWord && words.size <= 5) {
            if (has(t, "youtube", "ইউটিউব")) { DeviceActions.openYouTube(ctx); return Routed(true, "Opening YouTube") }
            if (has(t, "maps", "ম্যাপ")) { DeviceActions.openMaps(ctx); return Routed(true, "Opening Maps") }
            val name = words.filter { it !in stop }.joinToString(" ").trim()
            if (name.isNotEmpty()) {
                return if (DeviceActions.openAppByName(ctx, name)) Routed(true, "Opening $name")
                else Routed(true, "I couldn't find an app called $name")
            }
        }
        return Routed(false)
    }
}
